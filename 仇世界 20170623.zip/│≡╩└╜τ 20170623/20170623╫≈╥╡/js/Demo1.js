/**
 * Created by Administrator on 2017/6/24 0024.
 */
function change() {
    document.getElementById("book").innerHTML="现象级全球畅销书";
    document.getElementById("book").style.color="blue";
    document.getElementById("book").style.fontWeight="bold";
}
function allInput() {
    var allInput = document.getElementsByTagName("input");
    var all = "";
    for(var i = 0; i < allInput.length; i++) {
        all += allInput[i].value + "&nbsp;&nbsp;";
    }
    document.getElementById("po").innerHTML = all;
}
function seasonsInput() {
    var allInput = document.getElementsByName("season");
    var all = "";
    for(var i = 0; i < allInput.length; i++) {
        all += allInput[i].value + "&nbsp;&nbsp;";
    }
    document.getElementById("po").innerHTML = all;
}
function all() {
    document.write("");
}
