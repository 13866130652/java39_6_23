/**
 * Created by Administrator on 2017/6/24 0024.
 */
var count=0;
function change1(){
    var price = parseFloat(document.getElementById("dan1").textContent);
    // alert(typeof (jian))
    var num1=document.getElementById("num1");
    count=num1.value;
    if(count <= 1) {
        count = 1;
    }
    num1.value=--count;
    var sum=price*count;
    document.getElementById("price3").innerHTML=sum;
}

function chage1(){
    var price = parseFloat(document.getElementById("dan1").textContent);
    // alert(typeof (jian))
    var num1=document.getElementById("num1");
    count=num1.value;
    num1.value=++count;
    var sum=price*count;
    document.getElementById("price3").innerHTML=sum;
}
var coun=0;
function change2(){
    var price = parseInt(document.getElementById("dan2").textContent);
    // alert(typeof (jian))
    var num2=document.getElementById("num2");
    count1=num2.value;
    if(coun <= 1) {
        coun = 1;
    }
    num2.value=--coun;
    var sum1=price*coun;
    document.getElementById("price4").innerHTML=sum1;
}

function chage2(){
    var price = parseInt(document.getElementById("dan2").textContent);
    // alert(typeof (jian))
    var num2=document.getElementById("num2");
    coun=num2.value;
    num2.value=++coun;
    var sum1=price*coun;
    document.getElementById("price4").innerHTML=sum1;
}
function sum() {
    document.getElementById("sumPrice").innerHTML = (parseFloat(document.getElementById("price3").innerHTML) + parseFloat(document.getElementById("price4").innerHTML));
}
function disappear() {
    document.getElementById("box").style.display="none";
}