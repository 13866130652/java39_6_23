function jia1() {
	var ss = document.getElementById("span3");
	var tt = document.getElementById("span1");
	var yy = document.getElementById("span5");
	var zz = document.getElementById("span2");
	ss.innerHTML = parseInt(ss.textContent) + 1;
	var qian = 21.90 * parseInt(ss.textContent);
	tt.innerHTML = qian;
	yy.innerHTML = parseFloat(tt.textContent) + parseFloat(zz.textContent);
}

function jian1() {
	var ss = document.getElementById("span3");
	var tt = document.getElementById("span1");
	var yy = document.getElementById("span5");
	var zz = document.getElementById("span2");
	if(ss.innerHTML > 1) {
		ss.innerHTML = parseInt(ss.textContent) - 1;
	} else {
		ss.innerHTML = 1;
	}
	var qian = 21.90 * parseInt(ss.textContent);
	tt.innerHTML = qian;
	yy.innerHTML = parseFloat(tt.textContent) + parseFloat(zz.textContent);
}

function jia2() {
	var ss = document.getElementById("span4");
	var tt = document.getElementById("span1");
	var yy = document.getElementById("span5");
	var zz = document.getElementById("span2");
	ss.innerHTML = parseInt(ss.textContent) + 1;
	var qian = 24.10 * parseInt(ss.textContent);
	zz.innerHTML = qian;
	yy.innerHTML = parseFloat(tt.textContent) + parseFloat(zz.textContent);
}

function jian2() {
	var ss = document.getElementById("span4");
	var tt = document.getElementById("span1");
	var yy = document.getElementById("span5");
	var zz = document.getElementById("span2");
	if(ss.innerHTML > 1) {
		ss.innerHTML = parseInt(ss.textContent) - 1;
	} else {
		ss.innerHTML = 1;
	}
	var qian = 24.10 * parseInt(ss.textContent);
	zz.innerHTML = qian;
	yy.innerHTML = parseFloat(tt.textContent) + parseFloat(zz.textContent);
}