/**
 * Created by Administrator on 2017/6/25 0025.
 */

var i=1;
function Book(){
    document.getElementById("book").innerHTML=" 书名：岛上书店";
    i++;
    if(i%2==0){
        document.getElementById("book").innerHTML="现象级全球畅通书";
    }

}

function  all_input(){
    var arr=document.getElementsByTagName("input");
    var str="";
    for(var i=0;i<arr.length;i++){
        str+=arr[i].value+"&nbsp;&nbsp;"
    }
    document.getElementById("replace").innerHTML=str;
}

function  season_input(){
    var arr=document.getElementsByName("season");
    var str="";
    for(var i=0;i<arr.length;i++){
        str+=arr[i].value+"&nbsp;&nbsp;"
    }
    document.getElementById("replace").innerHTML=str;
}

function all_clear(){
    document.write("");
}
