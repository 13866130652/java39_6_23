/**
 * Created by Administrator on 2017/6/25 0025.
 */

//            function open_div(){
//                window.open("dang.html");
//            }

function guan(){
    window.close("dang.html");
}

function jian(){
    var arr=document.getElementById("num");
    var num1=parseInt(arr.textContent);
    var vrr=document.getElementById("money");
    var mon=parseFloat(vrr.textContent);


    var sum=document.getElementById("sp");
    if(num1>=2){
        num1--;
        arr.textContent=num1;
        var Sum=num1*mon;
        sum.textContent=Sum.toFixed(2);


    }else{
        alert("不能再减了,再减就没有啦!")
    }
    open_div();
}

function jia(){
    var arr=document.getElementById("num");
    var num1=parseInt(arr.textContent);
    var vrr=document.getElementById("money");
    var mon=parseFloat(vrr.textContent);
    var sum=document.getElementById("sp");
    num1++;
    arr.textContent=num1;
    var Sum=num1*mon;
    sum.textContent=Sum.toFixed(2);

    open_div();
}

function yi(){
    var flag=confirm("移入收藏后，将不在购物车显示，是否继续操作？");
    if(flag==true){
        alert("移入收藏成功！")
    }else{
        alert("收藏失败！")
    }
}

function ru(){
    var ar=document.getElementById("yi");
    ar.style.textDecoration="underline";
    ar.style.cursor="pointer";
}

function del(){
    var flag=confirm("您确定要删除商品吗？");
    if(flag==true){
        alert("删除成功！")
    }else{
        alert("删除失败！")
    }

}
function chu(){
    var ar=document.getElementById("del");
    ar.style.textDecoration="underline";
    ar.style.cursor="pointer";
}


function shao(){
    var arr=document.getElementById("shu");
    var num1=parseInt(arr.textContent);
    var vrr=document.getElementById("qian");
    var mon=parseFloat(vrr.textContent);
    var sum=document.getElementById("sp2");
    if(num1>=2){
        num1--;
        arr.textContent=num1;
        var Sum=num1*mon;
        sum.textContent=Sum.toFixed(2);
    }else{
        alert("不能再减了,再减就没有啦!")
    }
    open_div();
}

function add(){
    var arr=document.getElementById("shu");
    var num1=parseInt(arr.textContent);
    var vrr=document.getElementById("qian");
    var mon=parseFloat(vrr.textContent);
    var sum=document.getElementById("sp2");
    num1++;
    arr.textContent=num1;
    var Sum=num1*mon;
    sum.textContent=Sum.toFixed(2);
    open_div();
}

function yi2(){
    var flag=confirm("移入收藏后，将不在购物车显示，是否继续操作？");
    if(flag==true){
        alert("移入收藏成功！")
    }else{
        alert("收藏失败！")
    }

}
function ru2(){
    var ar=document.getElementById("yi2");
    ar.style.textDecoration="underline";
    ar.style.cursor="pointer";
}

function del2(){
    var flag=confirm("您确定要删除商品吗？");
    if(flag==true){
        alert("删除成功！")
    }else{
        alert("删除失败！")
    }

}
function chu2(){
    var ar=document.getElementById("del2");
    ar.style.textDecoration="underline";
    ar.style.cursor="pointer";

}
function out2(){
    var ar=document.getElementById("del2");
    ar.style.textDecoration="none";
}
function out1(){
    var ar=document.getElementById("yi2");
    ar.style.textDecoration="none";
}
function outt(){
    var ar=document.getElementById("del");
    ar.style.textDecoration="none";
}
function out(){
    var ar=document.getElementById("yi");
    ar.style.textDecoration="none";
}
function jisuan(){
//                var flag=confirm("您本次购买的商品信息如下：<br/>商品名称：白岩松：白说、岛上书店；" +
//                    "<br/>商品数量："+num+"件；<br/>商品总价："+zong+";<br/>运费0元；<br/>请确认以上信息是否有误!!!");
    var flag=confirm("您确定要提交订单吗？");
    if(flag==true){
        alert("您的订单已提交！")
    }else{
        alert("您取消了订单提交！")
    }
}


function open_div(){
    var sum1=document.getElementById("sp");
    var sum2=document.getElementById("sp2");
    var price1=parseFloat(sum1.textContent);
    var price2=parseFloat(sum2.textContent);
    var sumnum=price1+price2;
    var s=document.getElementById("sum");
    s.textContent=sumnum.toFixed(2);
    open_div();
}
