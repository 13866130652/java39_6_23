function earnName() {
	document.getElementById("book").innerHTML = "现象级全球畅销书";
	document.getElementById("book").style.color="red";
}

function seasonsInput() {
	var seasonInput = document.getElementsByName("season");
	var s = "";
	for(var i = 0; i < seasonInput.length; i++) {
		s = s + seasonInput[i].value + "&nbsp;&nbsp;";

	}
	document.getElementById("replace").innerHTML = s;

}

function allInput() {
	var allInput = document.getElementsByTagName("input");
	var s = "";
	for(var i = 0; i < allInput.length; i++) {
		s += allInput[i].value + "&nbsp;&nbsp;";

	}
	document.getElementById("replace").innerHTML = s;

}