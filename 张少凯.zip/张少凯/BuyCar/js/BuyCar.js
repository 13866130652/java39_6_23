/**
 * Created by zshock on 2017/6/25.
 */
var count = 0;

function upNum(){
    var allM = parseFloat(document.getElementById("allMoney").textContent);
    var price = document.getElementById("per1").textContent;
    var all = parseFloat(document.getElementById("allPrice").textContent);
    var num = document.getElementById("num");
    count = parseInt(num.value);
    num.value=++count;
    all = (parseFloat(price)*parseInt(num.value)).toFixed(2);
    allM = allM+parseFloat(price);
    document.getElementById("allMoney").innerHTML = allM.toFixed(2);
    document.getElementById("allPrice").innerHTML= all;

}
function upNum2(){
    var allM = parseFloat(document.getElementById("allMoney").textContent);
    var price = document.getElementById("per2").textContent;
    var all = parseFloat(document.getElementById("allPrice2").textContent);
    var num = document.getElementById("num2");
    count = parseInt(num.value);
    num.value=++count;
    all = parseFloat(price)*parseInt(num.value).toFixed(2);
    allM += parseFloat(price);
    document.getElementById("allMoney").innerHTML = allM.toFixed(2);
    document.getElementById("allPrice2").innerHTML= all.toFixed(2);


}
function lowNum(){
    var allM = parseFloat(document.getElementById("allMoney").textContent);
    var all = parseFloat(document.getElementById("allPrice").textContent);
    var price = parseFloat(document.getElementById("per1").textContent);
    var num = document.getElementById("num");
    count = parseInt(num.value);
    if(count<1){
        num.value = 0;
    }else{
        num.value=--count;
        all = parseFloat(price)*parseInt(num.value).toFixed(2);
        allM -= parseFloat(price);
        document.getElementById("allMoney").innerHTML = allM.toFixed(2);
        document.getElementById("allPrice").innerHTML= all.toFixed(2);
    }

}
function lowNum2(){
    var allM = parseFloat(document.getElementById("allMoney").textContent);
    var all = parseFloat(document.getElementById("allPrice2").textContent);
    var price = parseFloat(document.getElementById("per2").textContent);
    var num = document.getElementById("num2");
    count = parseInt(num.value);
    if(count<1){
        num.value = 0;
    }else{
        num.value=--count;
        all = parseFloat(price)*parseInt(num.value).toFixed(2);
        allM -= parseFloat(price);
        document.getElementById("allMoney").innerHTML = allM.toFixed(2);
        document.getElementById("allPrice2").innerHTML= all.toFixed(2);
    }

}
