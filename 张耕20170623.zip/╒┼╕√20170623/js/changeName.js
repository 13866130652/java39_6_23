function change() {
	document.getElementById("sp").innerHTML = "现象级全球畅销书";
}

function seasonMc() {
	var aInput = document.getElementsByName("season");
	var sStr = "";
	for(var i = 0; i < aInput.length; i++) {
		sStr += aInput[i].value + "&nbsp;&nbsp;";
	}
	document.getElementById("replace").innerHTML = sStr;
}

function inputNr() {
	var aInput = document.getElementsByTagName("input");
	var sStr = "";
	for(var i = 0; i < aInput.length; i++) {
		sStr += aInput[i].value + "&nbsp;&nbsp;";
	}
	document.getElementById("replace").innerHTML = sStr;
}

function clear(a) {
	var els = a.elements;
	//遍历所有表元素
	for(var i = 0; i < els.length; i++) {
		els[i].value = "";
	}
	return false;
}
//function clear() {
//	document.body.innerHTML = "";
//}