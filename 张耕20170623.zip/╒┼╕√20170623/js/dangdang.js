var sum1 = 20;
var sum2 = 30;

function minus() {
	var m = parseInt(document.getElementById("q").value);
	m--;
	if(m > 1) {
		document.getElementById("q").value = m;
		document.getElementById("s2").innerHTML = "¥" + (m * 20);
		sum1 = m * 20;
		document.getElementById("s4").innerHTML = (sum1 + sum2);
	} else {
		document.getElementById("q").value = "1";
		document.getElementById("s2").innerHTML = "¥" + 20;
		sum1 = 20;
		document.getElementById("s4").innerHTML = (sum1 + sum2);
	}

}

function plus() {
	var m = parseInt(document.getElementById("q").value);
	m++;
	document.getElementById("q").value = m;
	document.getElementById("s2").innerHTML = "¥" + (m * 20);
	sum1 = m * 20;
	document.getElementById("s4").innerHTML = (sum1 + sum2);
}

function minus1() {
	var b = parseInt(document.getElementById("w").value);
	b--;
	if(b > 1) {
		document.getElementById("w").value = b;
		document.getElementById("s3").innerHTML = "¥" + (b * 30);
		sum2 = b * 30;
		document.getElementById("s4").innerHTML = (sum1 + sum2);
	} else {
		document.getElementById("w").value = "1";
		document.getElementById("s3").innerHTML = "¥" + 30;
		sum2 = 30;
		document.getElementById("s4").innerHTML = (sum1 + sum2);
	}

}

function plus1() {
	var b = parseInt(document.getElementById("w").value);
	b++;
	document.getElementById("w").value = b;
	document.getElementById("s3").innerHTML = "¥" + (b * 30);
	sum2 = b * 30
	document.getElementById("s4").innerHTML = (sum1 + sum2);
}

function collect() {
	alert("你已经收藏!");
}

function cut() {
	var t = confirm("确认删除吗?");
	if(t == true) {
		return true;
	} else {
		return false;
	}
}

function close1() {
	window.open('', '_parent', '');
	window.opener = window;
	window.close();
}