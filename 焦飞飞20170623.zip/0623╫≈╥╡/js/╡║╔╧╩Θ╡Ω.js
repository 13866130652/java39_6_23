function huan(){
	var sp=document.getElementById("span1");
	var str="现象级全球畅销书";
	sp.innerHTML=str;
}
function neirong(){
	var arr=document.getElementsByTagName("input");
	var sp=document.getElementById("span2");
	sp.innerHTML="";
	for(var i=0;i<arr.length;i++){
		sp.innerHTML +=arr[i].value+"&nbsp";
	}
}
function ming(){
	var arr=document.getElementsByTagName("span");
	var spa=document.getElementById("span2");
	spa.innerHTML="";
	for(var i=1;i<arr.length-1;i++){
		spa.innerHTML +=arr[i].textContent+"&nbsp";
	}
}
function kong(){
	var box=document.getElementById("box");
	box.innerHTML="";
}
