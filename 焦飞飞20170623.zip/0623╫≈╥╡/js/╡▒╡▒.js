var num;

function jian() {
	var sp = document.getElementById("sp2");
	num = parseFloat(sp.textContent);
	if(num > 1) {
		num--;
	}
	sp.textContent = num;
	var danjia = document.getElementById("sp1");
	dan = parseFloat(danjia.textContent);
	var zongjia = document.getElementById("sp3");
	zong = num * dan;
	zongjia.textContent = zong;
	var jiesuan = document.getElementById("sp4");
	var zongjia1 = document.getElementById("sp33");
	jiesuan.innerHTML=parseFloat(zongjia.innerHTML)+parseFloat(zongjia1.innerHTML);
}

function jia() {
	var sp = document.getElementById("sp2");
	num = parseFloat(sp.textContent);
	num++;
	sp.textContent = num;
	var danjia = document.getElementById("sp1");
	dan = parseFloat(danjia.textContent);
	var zongjia = document.getElementById("sp3");
	zong = num * dan;
	zongjia.textContent = zong;
	var jiesuan = document.getElementById("sp4");
	var zongjia1 = document.getElementById("sp33");
	jiesuan.innerHTML=parseFloat(zongjia.innerHTML)+parseFloat(zongjia1.innerHTML);
}

function jian1() {
	var sp = document.getElementById("sp22");
	num = parseFloat(sp.textContent);
	if(num > 1) {
		num--;
	}
	sp.textContent = num;
	var danjia = document.getElementById("sp11");
	dan = parseFloat(danjia.textContent);
	var zongjia = document.getElementById("sp33");
	zong = num * dan;
	zongjia.textContent = zong;
	var jiesuan = document.getElementById("sp4");
	var zongjia1 = document.getElementById("sp3");
	jiesuan.innerHTML=parseFloat(zongjia.innerHTML)+parseFloat(zongjia1.innerHTML);
}

function jia1() {
	var sp = document.getElementById("sp22");
	num = parseFloat(sp.textContent);
	num++;
	sp.textContent = num;
	var danjia = document.getElementById("sp11");
	dan = parseFloat(danjia.textContent);
	var zongjia = document.getElementById("sp33");
	zong = num * dan;
	zongjia.textContent = zong;
	var jiesuan = document.getElementById("sp4");
	var zongjia1 = document.getElementById("sp3");
	jiesuan.innerHTML=parseFloat(zongjia.innerHTML)+parseFloat(zongjia1.innerHTML);
}