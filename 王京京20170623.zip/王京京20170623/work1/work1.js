/**
 * Created by WangJingJing on 2017/6/25.
 */
function change1(){
    document.getElementById("node").innerHTML="����ȫ������";
}
function change2(){
    var getInputs=document.getElementsByTagName("input");
    var str="";
    for(var i=0;i<getInputs.length;i++){
        str=str+getInputs[i].value+"<br/>";
    }
    document.getElementById("box").innerHTML=str;
}
function change3(){
    var seasons=document.getElementsByName("season");
    var str="";
    for(var i=0;i<seasons.length;i++){
        str=str+seasons[i].value+"<br/>";
    }
    document.getElementById("box").innerHTML=str;
}
function change4() {
    var str = "";
    document.getElementById("box").innerHTML = str;
}