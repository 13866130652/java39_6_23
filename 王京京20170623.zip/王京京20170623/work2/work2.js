/**
 * Created by WangJingJing on 2017/6/25.
 */
function change1(){
    var a="";
    a=document.getElementsByName("text2")[0].value;
    var b=parseInt(a);
    if(b<=1){
    }else{
        --b;
    }
    document.getElementsByName("text2")[0].value=""+b;
    c=document.getElementById("money1").innerHTML;
    d=parseFloat(c);
    var sum1=d*b;
    sum1=sum1.toFixed(2);
    document.getElementById("sum1").innerHTML=""+sum1;
}
function change2(){
    var a="";
    a=document.getElementsByName("text2")[0].value;
    var b=parseInt(a);
    ++b;
    document.getElementsByName("text2")[0].value=""+b;
    c=document.getElementById("money1").innerHTML;
    d=parseFloat(c);
    var sum1=d*b;
    sum1=sum1.toFixed(2);
    document.getElementById("sum1").innerHTML=""+sum1;
}
function change3(){
    var a="";
    a=document.getElementsByName("text5")[0].value;
    var b=parseInt(a);
    if(b<=1){
    }else{
        --b;
    }
    document.getElementsByName("text5")[0].value=""+b;
    c=document.getElementById("money2").innerHTML;
    d=parseFloat(c);
    var sum2=d*b;
    sum2=sum2.toFixed(2);
    document.getElementById("sum2").innerHTML=""+sum2;
}
function change4(){
    var a="";
    a=document.getElementsByName("text5")[0].value;
    var b=parseInt(a);
    ++b;
    document.getElementsByName("text5")[0].value=""+b;
    c=document.getElementById("money2").innerHTML;
    d=parseFloat(c);
    var sum2=d*b;
    sum2=sum2.toFixed(2);
    document.getElementById("sum2").innerHTML=""+sum2;
}
function change5(){
    sum1=parseFloat(document.getElementById("sum1").innerHTML);
    sum2=parseFloat(document.getElementById("sum2").innerHTML);
    sum3=sum1+sum2;
    sum3=sum3.toFixed(2);
    document.getElementById("money3").innerHTML=""+sum3;
}
function change6(){
    location="http://www.dangdang.com";
}