/**
 * Created by zsy on 2017/6/26.
 */
function change1(){
    var i=document.getElementById("name");
    i.innerHTML="����ȫ������";
}
function change2(){
    var i=document.getElementById("text");
    var st="";
    st+=document.getElementById("input1").value+"&nbsp;&nbsp;";
    st+=document.getElementById("input2").value+"&nbsp;&nbsp;";
    st+=document.getElementById("input3").value+"&nbsp;&nbsp;";
    st+=document.getElementById("input4").value+"&nbsp;&nbsp;";
    st+=document.getElementById("input5").value+"&nbsp;&nbsp;";
    st+=document.getElementById("input6").value+"&nbsp;&nbsp;";
    st+=document.getElementById("input7").value+"&nbsp;&nbsp;";
    st+=document.getElementById("input8").value+"&nbsp;&nbsp;";
    i.innerHTML=st;
}
function change3(){
    var i=document.getElementById("text");
    var st="";
    st+=document.getElementById("input2").value+"&nbsp;&nbsp;";
    st+=document.getElementById("input3").value+"&nbsp;&nbsp;";
    st+=document.getElementById("input4").value+"&nbsp;&nbsp;";
    st+=document.getElementById("input5").value+"&nbsp;&nbsp;";
    i.innerHTML=st;
}
function change4(){
    document.write("");
}