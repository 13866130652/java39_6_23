function alterBook()
{
   //document:通过id名称  获取 p对象  作用：给特殊的唯一标记更改内容 
   document.getElementById("book").innerHTML="<font color='red'>现象级全球畅销书</font>";	
	
	
}
function s_input()
{
  //点击四季名称  显示  四个季节的value值
 var  aInput=document.getElementsByName("season");
 var sStr="";
 for(var i=0;i<aInput.length;i++)
 {
	  sStr=sStr+aInput[i].value+"&nbsp;&nbsp;";
	 
 }
 //显示在最后一个p段落结构中
	document.getElementById("replace").innerHTML=sStr;
	
}

function  all_input()
{	
var aInput=document.getElementsByTagName("input");
var sStr="";
	for(var i=0;i<aInput.length;i++)
	{
		sStr+=aInput[i].value+"&nbsp;&nbsp;";
		
	}
	document.getElementById("replace").innerHTML=sStr;
	
	
	
}